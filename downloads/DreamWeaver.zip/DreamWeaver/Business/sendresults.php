<?php

$from="cullenrezendes@yahoo.com";
$email="cullenrezendes@yahoo.com";
$subject=$POST['Subject'];
$message=$POST['Message'];


mail ( $email, $subject, $message, "From:".$from);


Print "Your message has been Sent";

?>